-- Run this in your Supabase SQL Editor

-- Table 1: AI hiring chat sessions
CREATE TABLE chat_sessions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id text,
  email text,
  messages jsonb NOT NULL DEFAULT '[]',
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Table 2: Completed founder hiring requests
CREATE TABLE hiring_requests (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL,
  name text,
  company_name text,
  company_stage text,
  company_vision text,
  team_size text,
  culture text,
  decision_making text,
  work_style text,
  remote_or_office text,
  values text,
  work_life_balance text,
  growth_opportunity text,
  benefits text,
  role_title text,
  role_ownership text,
  greenfield_or_existing text,
  reporting_structure text,
  tech_stack text,
  must_haves text,
  nice_to_haves text,
  past_hiring_attempts text,
  bad_hire_description text,
  non_negotiables text,
  timeline text,
  timeline_driver text,
  budget text,
  budget_flexible boolean,
  equity boolean,
  full_transcript jsonb,
  created_at timestamptz DEFAULT now()
);

-- Table 3: Engineer talent applications
CREATE TABLE talent_applications (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  full_name text NOT NULL,
  email text NOT NULL,
  location text,
  primary_role text,
  years_experience text,
  core_skills text,
  github_portfolio text,
  linkedin text,
  best_project text,
  work_environment text,
  current_status text,
  availability_to_start text,
  work_type text,
  salary_expectation text,
  additional_notes text,
  application_status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Table 4: General contact/email captures
CREATE TABLE email_captures (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  email text NOT NULL,
  source text,
  created_at timestamptz DEFAULT now()
);
