require('dotenv').config()
const express = require('express')
const cors = require('cors')
const { createClient } = require('@supabase/supabase-js')
const Groq = require('groq-sdk')

const app = express()
app.use(cors())
app.use(express.json())
app.use(express.static('public'))

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
)

const groq = new Groq({
  apiKey: process.env.GROQ_API_KEY
})

process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err)
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// SYSTEM PROMPT — Jordan the AI recruiter
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const SYSTEM_PROMPT = `
You are Jordan — Bridgix's hiring partner. You are not a 
chatbot. You are the person founders talk to when they need 
to make a great engineering hire and cannot afford to get 
it wrong.

Your personality:
- Warm but direct. You care about getting this right.
- Genuinely curious. You ask follow-ups because you 
  actually want to understand, not to fill a form.
- Occasionally show personality — real enthusiasm when 
  something sounds exciting, honest pushback when something 
  sounds vague or like a red flag.
- Short replies. Never more than 3 sentences unless 
  summarising at the end.
- Never sound like a form. Never list questions.
  One question at a time. Always.
- Reference their specific answers back to them naturally.
  If they said fintech, say "for the fintech product" 
  not "for your product."
- Never repeat a question already answered.
- Never ask something you can infer from context.

You need to collect ALL of the following through natural 
conversation before completing. Weave through these 
organically — never in sequence like a checklist:

COMPANY UNDERSTANDING:
1. What the company does and who they build it for
2. Company stage — bootstrapped, seed, Series A etc
3. Big vision — where is this going in 3 years
4. Team size and day to day dynamic
5. Real culture — not polished, the honest version
6. How decisions get made
7. What kind of people thrive there and who struggles
8. Remote, hybrid or in-person
9. Pace — steady or fast and chaotic
10. Company values — what they would never compromise on
11. How they handle mistakes and pressure
12. Work-life balance approach
13. Growth path for the engineer
14. Learning and development investment
15. Benefits beyond salary — equity, flexibility etc
16. What people love about working there
17. What people find hardest about working there

ROLE UNDERSTANDING:
18. Role title and type
19. What the engineer actually owns and builds first
20. Greenfield or existing codebase
21. Who they work closest with day to day
22. Reporting structure — CTO, founder, or most senior 
    technical person themselves
23. Core tech stack
24. Must-have skills vs nice-to-haves
25. Past hiring attempts and what went wrong
26. What a bad hire looks like for this role
27. Non-negotiables in the person they hire
28. Timeline to hire
29. What is driving that timeline
30. Salary range and whether it is flexible
31. Equity available
32. Their name and best email for candidate profiles

Smart follow-ups:
- If vague on role: dig into what full-stack means 
  for their specific team
- If founding engineer: confirm if first technical hire
- If senior: ask what senior means to them specifically
- If past bad hire: ask what specifically went wrong
- If urgent: ask what is driving the urgency
- If culture sounds too polished: gently push for the 
  honest version
- If something sounds like a red flag: name it kindly

When you have collected all information respond with 
exactly: INTAKE_COMPLETE
Nothing else. No explanation.`

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 1 — AI CHAT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.post('/api/chat', async (req, res) => {
  try {
    const { messages, sessionId } = req.body

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array required' })
    }

    const completion = await groq.chat.completions.create({
      model: 'llama-3.3-70b-versatile',
      max_tokens: 300,
      temperature: 0.85,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        ...messages
      ]
    })

    const reply = completion.choices[0]?.message?.content || ''
    res.json({ reply })

  } catch (err) {
    console.error('POST /api/chat error:', err)
    res.status(500).json({ error: 'Something went wrong. Please try again.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 2 — SAVE CHAT
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.post('/api/save-chat', async (req, res) => {
  try {
    const { sessionId, email, messages } = req.body

    const { data: existing } = await supabase
      .from('chat_sessions')
      .select('id')
      .eq('session_id', sessionId)
      .single()

    if (existing) {
      await supabase
        .from('chat_sessions')
        .update({
          messages,
          email: email || null,
          updated_at: new Date().toISOString()
        })
        .eq('session_id', sessionId)
    } else {
      await supabase
        .from('chat_sessions')
        .insert({
          session_id: sessionId,
          email: email || null,
          messages
        })
    }

    res.json({ success: true })

  } catch (err) {
    console.error('POST /api/save-chat error:', err)
    res.status(500).json({ error: 'Could not save chat.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 3 — LOAD CHAT BY EMAIL
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.get('/api/load-chat', async (req, res) => {
  try {
    const { email } = req.query

    if (!email) {
      return res.status(400).json({ error: 'Email required' })
    }

    const { data, error } = await supabase
      .from('chat_sessions')
      .select('messages')
      .eq('email', email)
      .eq('completed', false)
      .order('updated_at', { ascending: false })
      .limit(1)
      .single()

    if (error || !data) {
      return res.json({ messages: null })
    }

    res.json({ messages: data.messages })

  } catch (err) {
    console.error('GET /api/load-chat error:', err)
    res.status(500).json({ error: 'Could not load chat.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 4 — COMPLETE INTAKE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.post('/api/complete-intake', async (req, res) => {
  try {
    const data = req.body

    await supabase
      .from('hiring_requests')
      .insert({
        email: data.email,
        name: data.name,
        company_name: data.company_name,
        company_stage: data.company_stage,
        company_vision: data.company_vision,
        team_size: data.team_size,
        culture: data.culture,
        decision_making: data.decision_making,
        work_style: data.work_style,
        remote_or_office: data.remote_or_office,
        values: data.values,
        work_life_balance: data.work_life_balance,
        growth_opportunity: data.growth_opportunity,
        benefits: data.benefits,
        role_title: data.role_title,
        role_ownership: data.role_ownership,
        greenfield_or_existing: data.greenfield_or_existing,
        reporting_structure: data.reporting_structure,
        tech_stack: data.tech_stack,
        must_haves: data.must_haves,
        nice_to_haves: data.nice_to_haves,
        past_hiring_attempts: data.past_hiring_attempts,
        bad_hire_description: data.bad_hire_description,
        non_negotiables: data.non_negotiables,
        timeline: data.timeline,
        timeline_driver: data.timeline_driver,
        budget: data.budget,
        budget_flexible: data.budget_flexible,
        equity: data.equity,
        full_transcript: data.messages
      })

    await supabase
      .from('chat_sessions')
      .update({ completed: true })
      .eq('session_id', data.sessionId)

    res.json({ success: true })

  } catch (err) {
    console.error('POST /api/complete-intake error:', err)
    res.status(500).json({ error: 'Could not save intake.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 5 — TALENT APPLICATION
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.post('/api/talent-application', async (req, res) => {
  try {
    const {
      full_name, email, location, primary_role,
      years_experience, core_skills, github_portfolio,
      linkedin, best_project, work_environment,
      current_status, availability_to_start, work_type,
      salary_expectation, additional_notes
    } = req.body

    if (!full_name || !email) {
      return res.status(400).json({ error: 'Name and email are required.' })
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Please enter a valid email address.' })
    }

    const { error } = await supabase
      .from('talent_applications')
      .insert({
        full_name, email, location, primary_role,
        years_experience, core_skills, github_portfolio,
        linkedin, best_project, work_environment,
        current_status, availability_to_start, work_type,
        salary_expectation, additional_notes,
        application_status: 'pending'
      })

    if (error) throw error

    res.json({ success: true })

  } catch (err) {
    console.error('POST /api/talent-application error:', err)
    res.status(500).json({ error: 'Could not submit application. Please try again.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ENDPOINT 6 — EMAIL CAPTURE
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.post('/api/email-capture', async (req, res) => {
  try {
    const { email, source } = req.body

    if (!email) {
      return res.status(400).json({ error: 'Email required.' })
    }

    await supabase
      .from('email_captures')
      .insert({ email, source: source || 'unknown' })

    res.json({ success: true })

  } catch (err) {
    console.error('POST /api/email-capture error:', err)
    res.status(500).json({ error: 'Could not save email.' })
  }
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// HEALTH CHECK
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'bridgix-backend' })
})

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// START SERVER
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Bridgix server running on port ${PORT}`)
})
