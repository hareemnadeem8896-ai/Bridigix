# Bridgix Backend

## Setup

1. Create a `.env` file based on `.env.example`
2. Add your SUPABASE_URL, SUPABASE_ANON_KEY, and GROQ_API_KEY
3. Run the SQL in `supabase-schema.sql` in your Supabase SQL editor
4. Deploy to Railway

## Deploy to Railway
1. Push this folder to GitHub
2. Connect Railway to the repo
3. Add environment variables in Railway dashboard
4. Deploy!

## Endpoints
- POST /api/chat
- POST /api/save-chat
- GET  /api/load-chat?email=xxx
- POST /api/complete-intake
- POST /api/talent-application
- POST /api/email-capture
- GET  /api/health
